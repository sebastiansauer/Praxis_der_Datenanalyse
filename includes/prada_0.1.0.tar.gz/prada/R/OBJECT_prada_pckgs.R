#' Vector of all packages needed for "Praktische Datenanalyse" and "Statistik_21"
#'


"prada_pckgs"